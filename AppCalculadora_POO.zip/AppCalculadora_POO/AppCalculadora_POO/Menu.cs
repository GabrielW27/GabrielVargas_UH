﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppCalculadora_POO
{
    internal class Menu
    {
        private Operaciones oper = null;
        public Menu()
        {
            this.oper = new Operaciones();
        }
        public void Mostrarmenu()
        {
            string opciones = "*** App Calculadora ***.\n";
            opciones += "Menu de opciones.\n";
            opciones += "1.Ingresar Numeros.\n";
            opciones += "2.Sumar.\n";
            opciones += "3.restar.\n";
            opciones += "4.Multiplicar.\n";
            opciones += "5.Dividir.\n";
            opciones += "6.salir.\n";
            int opcion = 0;
            do {
                Console.WriteLine(opciones);
                opcion = int.Parse(Console.ReadLine());
                switch (opcion)
                {
                    case 1:
                        this.SolicitarNumero();
                        break;
                    case 2:
                        Console.WriteLine("El resultado de la suma es: "+this.oper.sumar());
                        break;
                    case 3:
                        Console.WriteLine("El resultado de la resta es: " + this.oper.restar());
                        break;
                    case 4:
                        Console.WriteLine("El resultado de la multiplicacion es: " + this.oper.multiplicar());
                        break;
                    case 5:
                        Console.WriteLine("El resultado de la division es: " + this.oper.dividir());
                        break;
                    case 6:
                        break;

                }
            } while (opcion !=6);
        }
        private void SolicitarNumero()
        {
            Console.WriteLine("Digite el primer Numero");
            this.oper.Numero1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Digite el segundo Numero");
            this.oper.Numero2 = float.Parse(Console.ReadLine());
        }
    }
}
