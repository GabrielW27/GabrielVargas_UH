﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppCalculadora_POO
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Menu menu;
            menu = new Menu();

            menu.Mostrarmenu();

            Console.WriteLine("Presione cuakquier tecla para finalizar");
            Console.ReadKey();
            Environment.Exit(0);
        }
    }
}
