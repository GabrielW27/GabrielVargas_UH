﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppCalculadora_POO
{
    internal class Operaciones
    {
        private float num1 = 0;
        private float num2 = 0;
        private float result = 0;

        public float Numero1
        {
            get { return this.num1; }
            set { this.num1 = value; }
        }
        public float Numero2
        {
            get { return this.num2; }
            set { this.num2 = value; }
        }
        public float sumar()
        {
            this.result = this.num1 + this.num2;
            return this.result;
        }
        public float restar()
        {
            this.result = this.num1 - this.num2;
            return this.result;
        }
        public float multiplicar()
        {
            this.result = this.num1 * this.num2;
            return this.result;
        }
        public float dividir()
        {
            this.result = this.num1 / this.num2;
            return this.result;
        }

    }
}
